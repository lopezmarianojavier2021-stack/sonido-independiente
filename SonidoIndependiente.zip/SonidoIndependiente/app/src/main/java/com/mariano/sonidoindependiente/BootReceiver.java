package com.mariano.sonidoindependiente;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        SharedPreferences prefs = context.getSharedPreferences("SonidoIndependiente", Context.MODE_PRIVATE);

        boolean arranque = prefs.getBoolean("arranque", false);
        boolean activado = prefs.getBoolean("activado", false);
        if (!arranque || !activado) return;

        Set<String> appsSet = prefs.getStringSet("apps", new HashSet<>());
        String dispositivo = prefs.getString("dispositivo_nombre", null);
        String address = prefs.getString("dispositivo_address", null);
        int volumen = prefs.getInt("volumen", 80);

        if (appsSet.isEmpty() || dispositivo == null) return;

        Intent serviceIntent = new Intent(context, AudioRedirectService.class);
        serviceIntent.putStringArrayListExtra("apps", new ArrayList<>(appsSet));
        serviceIntent.putExtra("dispositivo", dispositivo);
        serviceIntent.putExtra("address", address);
        serviceIntent.putExtra("volumen", volumen);
        serviceIntent.putExtra("temporizador", 0);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }
}
