package com.mariano.sonidoindependiente;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PerfilActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private List<Perfil> perfiles = new ArrayList<>();
    private PerfilAdapter adapter;
    private ArrayList<String> appsActuales;
    private String dispositivoActual;
    private int volumenActual;
    private boolean temporizadorActual;
    private boolean arranqueActual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.perfiles);
        }

        prefs = getSharedPreferences("SonidoIndependiente", Context.MODE_PRIVATE);

        appsActuales      = getIntent().getStringArrayListExtra("apps");
        dispositivoActual = getIntent().getStringExtra("dispositivo");
        volumenActual     = getIntent().getIntExtra("volumen", 80);
        temporizadorActual = getIntent().getBooleanExtra("temporizador_activo", false);
        arranqueActual    = getIntent().getBooleanExtra("arranque", false);
        if (appsActuales == null) appsActuales = new ArrayList<>();

        cargarPerfiles();

        RecyclerView recycler = findViewById(R.id.recyclerPerfiles);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PerfilAdapter(perfiles, this::aplicarPerfil, this::eliminarPerfil, this::configurarWifi);
        recycler.setAdapter(adapter);

        MaterialButton btnGuardar = findViewById(R.id.btnGuardarPerfil);
        btnGuardar.setOnClickListener(v -> mostrarDialogoGuardar());

        MaterialButton btnExportar = findViewById(R.id.btnExportarPerfiles);
        btnExportar.setOnClickListener(v -> mostrarDialogoExportar());

        MaterialButton btnImportar = findViewById(R.id.btnImportarPerfiles);
        btnImportar.setOnClickListener(v -> abrirSelectorArchivo());

        mostrarWifiActual();
        actualizarVistaSinPerfiles();
    }

    private void mostrarWifiActual() {
        TextView tvWifi = findViewById(R.id.tvWifiActual);
        String ssid = obtenerSsidActual();
        if (ssid != null) {
            tvWifi.setText("WiFi actual: " + ssid);
            tvWifi.setVisibility(View.VISIBLE);
            tvWifi.setContentDescription("Red WiFi actual: " + ssid + ". Podés vincular un perfil a esta red.");
        } else {
            tvWifi.setText("No conectado a WiFi");
            tvWifi.setVisibility(View.VISIBLE);
        }
    }

    private String obtenerSsidActual() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null || !wm.isWifiEnabled()) return null;
            WifiInfo info = wm.getConnectionInfo();
            if (info == null) return null;
            String ssid = info.getSSID();
            if (ssid == null || ssid.equals("<unknown ssid>")) return null;
            return ssid.replace("\"", "");
        } catch (Exception e) {
            return null;
        }
    }

    private void cargarPerfiles() {
        perfiles.clear();
        String json = prefs.getString("perfiles_json", "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                Perfil p = new Perfil();
                p.nombre      = obj.getString("nombre");
                p.dispositivo = obj.optString("dispositivo", "");
                p.volumen     = obj.optInt("volumen", 80);
                p.temporizador = obj.optBoolean("temporizador", false);
                p.arranque    = obj.optBoolean("arranque", false);
                p.wifiSsid    = obj.optString("wifi_ssid", "");
                JSONArray appsArr = obj.optJSONArray("apps");
                p.apps = new ArrayList<>();
                if (appsArr != null) {
                    for (int j = 0; j < appsArr.length(); j++) {
                        p.apps.add(appsArr.getString(j));
                    }
                }
                perfiles.add(p);
            }
        } catch (Exception ignored) {}
    }

    private void guardarPerfiles() {
        try {
            JSONArray arr = new JSONArray();
            for (Perfil p : perfiles) {
                JSONObject obj = new JSONObject();
                obj.put("nombre",       p.nombre);
                obj.put("dispositivo",  p.dispositivo);
                obj.put("volumen",      p.volumen);
                obj.put("temporizador", p.temporizador);
                obj.put("arranque",     p.arranque);
                obj.put("wifi_ssid",    p.wifiSsid != null ? p.wifiSsid : "");
                obj.put("apps", new JSONArray(p.apps));
                arr.put(obj);
            }
            prefs.edit().putString("perfiles_json", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void mostrarDialogoGuardar() {
        EditText et = new EditText(this);
        et.setHint("Nombre del perfil (ej: Auto nocturno)");
        et.setContentDescription("Ingresá el nombre del perfil");
        et.setPadding(48, 32, 48, 32);

        String appsDesc = appsActuales.isEmpty()
            ? "todo el audio"
            : appsActuales.size() + " app(s)";

        String resumen = appsDesc
            + ", dispositivo: " + (dispositivoActual != null ? dispositivoActual : "ninguno")
            + ", volumen: " + volumenActual + "%"
            + ", temporizador: " + (temporizadorActual ? "sí" : "no")
            + ", arranque automático: " + (arranqueActual ? "sí" : "no") + ".";

        new AlertDialog.Builder(this)
            .setTitle(R.string.nuevo_perfil)
            .setMessage("Se guardará: " + resumen)
            .setView(et)
            .setPositiveButton(R.string.guardar, (d, w) -> {
                String nombre = et.getText().toString().trim();
                if (nombre.isEmpty()) {
                    Toast.makeText(this, "Escribí un nombre para el perfil", Toast.LENGTH_SHORT).show();
                    return;
                }
                Perfil p = new Perfil();
                p.nombre      = nombre;
                p.apps        = new ArrayList<>(appsActuales);
                p.dispositivo = dispositivoActual != null ? dispositivoActual : "";
                p.volumen     = volumenActual;
                p.temporizador = temporizadorActual;
                p.arranque    = arranqueActual;
                p.wifiSsid    = "";
                perfiles.add(p);
                guardarPerfiles();
                adapter.notifyItemInserted(perfiles.size() - 1);
                actualizarVistaSinPerfiles();
                Toast.makeText(this, getString(R.string.perfil_guardado), Toast.LENGTH_SHORT).show();
                announceForAccessibility("Perfil " + nombre + " guardado.");
            })
            .setNegativeButton(R.string.cancelar, null)
            .show();
    }

    private void configurarWifi(int position) {
        Perfil p = perfiles.get(position);
        String ssidActual = obtenerSsidActual();

        String[] opciones;
        if (ssidActual != null) {
            opciones = new String[]{
                "Vincular a WiFi actual (" + ssidActual + ")",
                "Quitar vinculación WiFi",
                "Cancelar"
            };
        } else {
            opciones = new String[]{
                "No hay WiFi disponible ahora",
                "Quitar vinculación WiFi",
                "Cancelar"
            };
        }

        String estado = (p.wifiSsid != null && !p.wifiSsid.isEmpty())
            ? "Vinculado a: " + p.wifiSsid
            : "Sin vinculación WiFi";

        new AlertDialog.Builder(this)
            .setTitle("Modo Escena — " + p.nombre)
            .setMessage("Este perfil se activará automáticamente al conectarte a la red elegida.\n\nEstado actual: " + estado)
            .setItems(opciones, (d, which) -> {
                if (which == 0 && ssidActual != null) {
                    p.wifiSsid = ssidActual;
                    guardarPerfiles();
                    adapter.notifyItemChanged(position);
                    announceForAccessibility("Perfil " + p.nombre + " vinculado a la red " + ssidActual + ".");
                    Toast.makeText(this, "Vinculado a " + ssidActual, Toast.LENGTH_SHORT).show();
                } else if (which == 1) {
                    p.wifiSsid = "";
                    guardarPerfiles();
                    adapter.notifyItemChanged(position);
                    announceForAccessibility("Vinculación WiFi eliminada del perfil " + p.nombre + ".");
                    Toast.makeText(this, "Vinculación WiFi eliminada", Toast.LENGTH_SHORT).show();
                }
            })
            .show();
    }

    private void aplicarPerfil(Perfil p) {
        Intent result = new Intent();
        result.putStringArrayListExtra("apps", new ArrayList<>(p.apps));
        result.putExtra("dispositivo",        p.dispositivo);
        result.putExtra("volumen",            p.volumen);
        result.putExtra("temporizador_activo", p.temporizador);
        result.putExtra("arranque",           p.arranque);
        setResult(RESULT_OK, result);
        Toast.makeText(this, "Perfil '" + p.nombre + "' aplicado", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void eliminarPerfil(int position) {
        String nombre = perfiles.get(position).nombre;
        new AlertDialog.Builder(this)
            .setTitle("Eliminar perfil")
            .setMessage("¿Eliminar el perfil '" + nombre + "'?")
            .setPositiveButton(R.string.eliminar, (d, w) -> {
                perfiles.remove(position);
                guardarPerfiles();
                adapter.notifyItemRemoved(position);
                actualizarVistaSinPerfiles();
                Toast.makeText(this, getString(R.string.perfil_eliminado), Toast.LENGTH_SHORT).show();
                announceForAccessibility("Perfil " + nombre + " eliminado.");
            })
            .setNegativeButton(R.string.cancelar, null)
            .show();
    }

    private void actualizarVistaSinPerfiles() {
        TextView tvSin = findViewById(R.id.tvSinPerfiles);
        tvSin.setVisibility(perfiles.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ─── EXPORTAR ────────────────────────────────────────────────

    private void mostrarDialogoExportar() {
        if (perfiles.isEmpty()) {
            Toast.makeText(this, "No hay perfiles guardados para exportar.", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] opciones = new String[perfiles.size() + 1];
        opciones[0] = "Exportar TODOS los perfiles (" + perfiles.size() + ")";
        for (int i = 0; i < perfiles.size(); i++) {
            opciones[i + 1] = "Solo: " + perfiles.get(i).nombre;
        }

        new AlertDialog.Builder(this)
            .setTitle("Exportar copia de seguridad")
            .setMessage("Elegí qué perfiles querés exportar. El archivo se puede guardar en Google Drive, WhatsApp, correo o donde quieras.")
            .setItems(opciones, (d, which) -> {
                if (which == 0) {
                    exportarPerfiles(perfiles, "todos");
                } else {
                    List<Perfil> uno = new ArrayList<>();
                    uno.add(perfiles.get(which - 1));
                    exportarPerfiles(uno, perfiles.get(which - 1).nombre);
                }
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void exportarPerfiles(List<Perfil> lista, String sufijo) {
        try {
            // Armar el JSON del backup
            JSONObject backup = new JSONObject();
            backup.put("app",     "SonidoIndependiente");
            backup.put("version", "1.0");
            backup.put("fecha",   new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date()));

            JSONArray arr = new JSONArray();
            for (Perfil p : lista) {
                JSONObject obj = new JSONObject();
                obj.put("nombre",      p.nombre);
                obj.put("dispositivo", p.dispositivo != null ? p.dispositivo : "");
                obj.put("volumen",     p.volumen);
                obj.put("temporizador", p.temporizador);
                obj.put("arranque",    p.arranque);
                obj.put("wifi_ssid",   p.wifiSsid != null ? p.wifiSsid : "");
                obj.put("apps",        new JSONArray(p.apps != null ? p.apps : new ArrayList<>()));
                arr.put(obj);
            }
            backup.put("perfiles", arr);

            String contenido = backup.toString(2);
            String nombre    = "SonidoIndependiente_backup_"
                + sufijo.replaceAll("[^a-zA-Z0-9]", "_") + ".json";

            // Preguntar dónde guardar
            String[] destinos = {
                "Almacenamiento interno (carpeta Sonido Independiente)",
                "Tarjeta SD (carpeta Sonido Independiente)",
                "Compartir (WhatsApp, Drive, correo, etc.)"
            };

            new AlertDialog.Builder(this)
                .setTitle("¿Dónde guardar el backup?")
                .setItems(destinos, (d, which) -> {
                    if (which == 0) {
                        guardarEnAlmacenamiento(contenido, nombre, false);
                    } else if (which == 1) {
                        guardarEnAlmacenamiento(contenido, nombre, true);
                    } else {
                        compartirBackup(contenido, nombre);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();

        } catch (Exception e) {
            Toast.makeText(this, "Error al preparar el backup: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void guardarEnAlmacenamiento(String contenido, String nombre, boolean usarSd) {
        try {
            File carpeta = null;

            if (usarSd) {
                // Tarjeta SD: buscar entre los directorios externos disponibles
                File[] externos = getExternalFilesDirs(null);
                if (externos != null && externos.length > 1 && externos[1] != null) {
                    // índice 1 suele ser la SD cuando hay una montada
                    carpeta = new File(externos[1].getParentFile().getParentFile().getParentFile().getParentFile(),
                        "Sonido Independiente");
                } else if (externos != null && externos.length > 0 && externos[0] != null) {
                    // Fallback al primer externo disponible
                    carpeta = new File(externos[0].getParentFile().getParentFile().getParentFile().getParentFile(),
                        "Sonido Independiente");
                }
                if (carpeta == null) {
                    Toast.makeText(this, "No se encontró tarjeta SD. Se guardará en el almacenamiento interno.", Toast.LENGTH_LONG).show();
                    usarSd = false;
                }
            }

            if (!usarSd || carpeta == null) {
                // Almacenamiento interno público: Documents/Sonido Independiente
                File docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
                carpeta = new File(docs, "Sonido Independiente");
            }

            if (!carpeta.exists()) {
                boolean creada = carpeta.mkdirs();
                if (!creada) {
                    Toast.makeText(this, "No se pudo crear la carpeta. Verificá los permisos de almacenamiento.", Toast.LENGTH_LONG).show();
                    return;
                }
            }

            File archivo = new File(carpeta, nombre);
            FileOutputStream fos = new FileOutputStream(archivo);
            fos.write(contenido.getBytes("UTF-8"));
            fos.close();

            String ruta = archivo.getAbsolutePath();
            String msg  = "Backup guardado en:\n" + ruta;

            new AlertDialog.Builder(this)
                .setTitle("Backup guardado")
                .setMessage(msg + "\n\nPodés encontrarlo con cualquier explorador de archivos en la carpeta \"Sonido Independiente\".")
                .setPositiveButton("Entendido", null)
                .setNeutralButton("Compartir también", (d, w) -> compartirArchivo(archivo, nombre))
                .show();

            announceForAccessibility("Backup guardado en el dispositivo en la carpeta Sonido Independiente.");

        } catch (Exception e) {
            new AlertDialog.Builder(this)
                .setTitle("Error al guardar")
                .setMessage("No se pudo guardar el archivo. En Android 10 o superior puede ser necesario activar el permiso de almacenamiento manualmente desde los ajustes del sistema.\n\nDetalle: " + e.getMessage())
                .setPositiveButton("Entendido", null)
                .show();
        }
    }

    private void compartirArchivo(File archivo, String nombre) {
        try {
            Uri uri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", archivo);
            } else {
                uri = Uri.fromFile(archivo);
            }
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/json");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, "Copia de seguridad — Sonido Independiente");
            share.putExtra(Intent.EXTRA_TEXT,
                "Adjunto la copia de seguridad de mis perfiles de Sonido Independiente.\n" +
                "Para importarla, abrí la app, entrá a Perfiles y tocá Importar.");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "Compartir backup"));
        } catch (Exception e) {
            Toast.makeText(this, "Error al compartir: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void compartirBackup(String contenido, String nombre) {
        try {
            // Guardar temporalmente en directorio privado para poder compartirlo
            File tmp = new File(getExternalFilesDir(null), nombre);
            FileOutputStream fos = new FileOutputStream(tmp);
            fos.write(contenido.getBytes("UTF-8"));
            fos.close();

            Uri uri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", tmp);
            } else {
                uri = Uri.fromFile(tmp);
            }

            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/json");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, "Copia de seguridad — Sonido Independiente");
            share.putExtra(Intent.EXTRA_TEXT,
                "Adjunto la copia de seguridad de mis perfiles de Sonido Independiente.\n" +
                "Para importarla, abrí la app, entrá a Perfiles y tocá Importar.");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "Compartir backup"));
            announceForAccessibility("Copia de seguridad lista. Elegí dónde compartirla.");

        } catch (Exception e) {
            Toast.makeText(this, "Error al compartir: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ─── IMPORTAR ────────────────────────────────────────────────

    private static final int REQUEST_IMPORTAR = 500;

    private void abrirSelectorArchivo() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "*/*"});
        try {
            startActivityForResult(
                Intent.createChooser(intent, "Seleccioná el archivo de backup"),
                REQUEST_IMPORTAR);
        } catch (Exception e) {
            Toast.makeText(this, "No se encontró una app para abrir archivos.", Toast.LENGTH_SHORT).show();
        }
    }

    private void importarDesdeUri(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            if (is == null) { Toast.makeText(this, "No se pudo leer el archivo.", Toast.LENGTH_SHORT).show(); return; }

            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String linea;
            while ((linea = br.readLine()) != null) sb.append(linea);
            br.close();

            JSONObject backup = new JSONObject(sb.toString());

            if (!backup.optString("app").equals("SonidoIndependiente")) {
                new AlertDialog.Builder(this)
                    .setTitle("Archivo no reconocido")
                    .setMessage("El archivo no parece ser una copia de seguridad de Sonido Independiente. ¿Intentar importarlo igual?")
                    .setPositiveButton("Sí, importar", (d, w) -> procesarImportacion(backup))
                    .setNegativeButton("Cancelar", null)
                    .show();
                return;
            }

            procesarImportacion(backup);

        } catch (Exception e) {
            new AlertDialog.Builder(this)
                .setTitle("Error al importar")
                .setMessage("No se pudo leer el archivo. Asegurate de que sea un backup válido de Sonido Independiente.\n\nDetalle: " + e.getMessage())
                .setPositiveButton("Entendido", null)
                .show();
        }
    }

    private void procesarImportacion(JSONObject backup) {
        try {
            JSONArray arr = backup.optJSONArray("perfiles");
            if (arr == null || arr.length() == 0) {
                Toast.makeText(this, "El archivo no contiene perfiles.", Toast.LENGTH_SHORT).show();
                return;
            }

            String fecha = backup.optString("fecha", "fecha desconocida");
            int cantidad = arr.length();

            new AlertDialog.Builder(this)
                .setTitle("Importar " + cantidad + " perfil(es)")
                .setMessage("Backup del " + fecha + ".\n\n¿Querés agregar estos perfiles a los que ya tenés, o reemplazar todo?")
                .setPositiveButton("Agregar", (d, w) -> importar(arr, false))
                .setNeutralButton("Reemplazar todo", (d, w) -> {
                    new AlertDialog.Builder(this)
                        .setTitle("Confirmar")
                        .setMessage("Esto borrará todos tus perfiles actuales y los reemplazará con los del backup. ¿Estás seguro?")
                        .setPositiveButton("Sí, reemplazar", (d2, w2) -> importar(arr, true))
                        .setNegativeButton("Cancelar", null)
                        .show();
                })
                .setNegativeButton("Cancelar", null)
                .show();

        } catch (Exception e) {
            Toast.makeText(this, "Error al procesar el backup.", Toast.LENGTH_SHORT).show();
        }
    }

    private void importar(JSONArray arr, boolean reemplazar) {
        try {
            if (reemplazar) perfiles.clear();

            int importados = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                Perfil p = new Perfil();
                p.nombre      = obj.optString("nombre", "Perfil importado");
                p.dispositivo = obj.optString("dispositivo", "");
                p.volumen     = obj.optInt("volumen", 80);
                p.temporizador = obj.optBoolean("temporizador", false);
                p.arranque    = obj.optBoolean("arranque", false);
                p.wifiSsid    = obj.optString("wifi_ssid", "");
                p.apps        = new ArrayList<>();
                JSONArray appsArr = obj.optJSONArray("apps");
                if (appsArr != null) {
                    for (int j = 0; j < appsArr.length(); j++) {
                        p.apps.add(appsArr.getString(j));
                    }
                }
                perfiles.add(p);
                importados++;
            }

            guardarPerfiles();
            adapter.notifyDataSetChanged();
            actualizarVistaSinPerfiles();

            String msg = importados + " perfil(es) importado(s) correctamente.";
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            announceForAccessibility(msg);

        } catch (Exception e) {
            Toast.makeText(this, "Error al importar los perfiles.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORTAR && resultCode == RESULT_OK && data != null && data.getData() != null) {
            importarDesdeUri(data.getData());
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    static class Perfil {
        String nombre;
        List<String> apps;
        String dispositivo;
        int volumen;
        boolean temporizador;
        boolean arranque;
        String wifiSsid;

        String resumen() {
            String appsStr = (apps == null || apps.isEmpty()) ? "todo el audio" : apps.size() + " app(s)";
            String wifi = (wifiSsid != null && !wifiSsid.isEmpty()) ? " · WiFi: " + wifiSsid : "";
            String extras = "";
            if (temporizador) extras += " · con temporizador";
            if (arranque)     extras += " · arranque auto";
            return appsStr + " · " + dispositivo + " · " + volumen + "%" + extras + wifi;
        }
    }

    static class PerfilAdapter extends RecyclerView.Adapter<PerfilAdapter.VH> {
        interface OnApply  { void apply(Perfil p); }
        interface OnDelete { void delete(int pos); }
        interface OnWifi   { void configWifi(int pos); }

        private List<Perfil> perfiles;
        private OnApply  onApply;
        private OnDelete onDelete;
        private OnWifi   onWifi;

        PerfilAdapter(List<Perfil> perfiles, OnApply onApply, OnDelete onDelete, OnWifi onWifi) {
            this.perfiles = perfiles;
            this.onApply  = onApply;
            this.onDelete = onDelete;
            this.onWifi   = onWifi;
        }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_perfil, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            Perfil p = perfiles.get(position);
            holder.tvNombre.setText(p.nombre);
            holder.tvResumen.setText(p.resumen());

            boolean tieneWifi = p.wifiSsid != null && !p.wifiSsid.isEmpty();
            holder.tvWifi.setVisibility(tieneWifi ? View.VISIBLE : View.GONE);
            if (tieneWifi) {
                holder.tvWifi.setText("Modo Escena: se activa con WiFi \"" + p.wifiSsid + "\"");
                holder.tvWifi.setContentDescription("Modo Escena activo: este perfil se activa automáticamente al conectarte a la red " + p.wifiSsid);
            }

            holder.btnAplicar.setOnClickListener(v -> onApply.apply(p));
            holder.btnAplicar.setContentDescription("Aplicar perfil " + p.nombre);
            holder.btnEliminar.setOnClickListener(v -> onDelete.delete(holder.getAdapterPosition()));
            holder.btnEliminar.setContentDescription("Eliminar perfil " + p.nombre);
            holder.btnWifi.setOnClickListener(v -> onWifi.configWifi(holder.getAdapterPosition()));
            holder.btnWifi.setText(tieneWifi ? "WiFi vinculado" : "Vincular WiFi");
            holder.btnWifi.setContentDescription(tieneWifi
                ? "Modo Escena configurado con red " + p.wifiSsid + ". Tocá para cambiar."
                : "Vincular este perfil a una red WiFi para activación automática.");

            holder.itemView.setContentDescription(
                "Perfil: " + p.nombre + ". " + p.resumen()
            );
        }

        @Override
        public int getItemCount() { return perfiles.size(); }

        static class VH extends RecyclerView.ViewHolder {
            TextView tvNombre, tvResumen, tvWifi;
            MaterialButton btnAplicar, btnEliminar, btnWifi;
            VH(View v) {
                super(v);
                tvNombre   = v.findViewById(R.id.tvPerfilNombre);
                tvResumen  = v.findViewById(R.id.tvPerfilResumen);
                tvWifi     = v.findViewById(R.id.tvPerfilWifi);
                btnAplicar = v.findViewById(R.id.btnAplicarPerfil);
                btnEliminar = v.findViewById(R.id.btnEliminarPerfil);
                btnWifi    = v.findViewById(R.id.btnWifiPerfil);
            }
        }
    }
}
