package com.mariano.sonidoindependiente;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class ConfiguracionesActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    // switches
    private SwitchMaterial switchNocturno;
    private SwitchMaterial switchAuriculares;
    private SwitchMaterial switchLlamadas;
    private SwitchMaterial switchFade;
    private SwitchMaterial switchAnuncioVoz;
    private SwitchMaterial switchBateria;
    private SwitchMaterial switchSilencioFoco;
    private SwitchMaterial switchAutoActualizacion;

    private TextView tvVersionActual;
    private TextView tvEstadoActualizacion;
    private com.google.android.material.button.MaterialButton btnBuscarActualizacion;

    private ActualizadorService actualizador;

    // valores
    private TextView tvNocturnoRango;
    private TextView tvVolNocturno;
    private TextView tvFadeDesc;
    private TextView tvBateriaDesc;
    private TextView tvEtiquetaValor;

    private SeekBar seekVolNocturno;
    private View rowNocturnoHorario;
    private View rowVolNocturno;
    private View rowFadeVel;
    private View rowBateriaUmbral;
    private View rowEtiqueta;

    private int horaNocturnaInicio = 22;
    private int horaNocturnaFin    = 8;
    private int volNocturno        = 40;
    private int fadeSegundos       = 3;
    private int bateriaUmbral      = 15;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuraciones);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Configuraciones");
        }

        prefs = getSharedPreferences("SonidoIndependiente", Context.MODE_PRIVATE);

        inicializarVistas();
        cargarValores();
        configurarListeners();
    }

    private void inicializarVistas() {
        switchNocturno      = findViewById(R.id.switchNocturno);
        switchAuriculares   = findViewById(R.id.switchAuriculares);
        switchLlamadas      = findViewById(R.id.switchLlamadas);
        switchFade          = findViewById(R.id.switchFade);
        switchAnuncioVoz    = findViewById(R.id.switchAnuncioVoz);
        switchBateria       = findViewById(R.id.switchBateria);
        switchSilencioFoco  = findViewById(R.id.switchSilencioFoco);
        switchAutoActualizacion = findViewById(R.id.switchAutoActualizacion);

        tvVersionActual        = findViewById(R.id.tvVersionActual);
        tvEstadoActualizacion  = findViewById(R.id.tvEstadoActualizacion);
        btnBuscarActualizacion = findViewById(R.id.btnBuscarActualizacion);

        actualizador = new ActualizadorService(this);

        tvNocturnoRango     = findViewById(R.id.tvNocturnoRango);
        tvVolNocturno       = findViewById(R.id.tvVolNocturnoValor);
        tvFadeDesc          = findViewById(R.id.tvFadeDesc);
        tvBateriaDesc       = findViewById(R.id.tvBateriaDesc);
        tvEtiquetaValor     = findViewById(R.id.tvEtiquetaValor);

        seekVolNocturno     = findViewById(R.id.seekVolNocturno);
        rowNocturnoHorario  = findViewById(R.id.rowNocturnoHorario);
        rowVolNocturno      = findViewById(R.id.rowVolNocturno);
        rowFadeVel          = findViewById(R.id.rowFadeVel);
        rowBateriaUmbral    = findViewById(R.id.rowBateriaUmbral);
        rowEtiqueta         = findViewById(R.id.rowEtiqueta);
    }

    private void cargarValores() {
        horaNocturnaInicio = prefs.getInt("nocturno_inicio", 22);
        horaNocturnaFin    = prefs.getInt("nocturno_fin", 8);
        volNocturno        = prefs.getInt("nocturno_vol", 40);
        fadeSegundos       = prefs.getInt("fade_seg", 3);
        bateriaUmbral      = prefs.getInt("bateria_umbral", 15);

        switchNocturno.setChecked(prefs.getBoolean("nocturno_activo", false));
        switchAuriculares.setChecked(prefs.getBoolean("auriculares_pausa", false));
        switchLlamadas.setChecked(prefs.getBoolean("llamadas_pausa", true));
        switchFade.setChecked(prefs.getBoolean("fade_activo", true));
        switchAnuncioVoz.setChecked(prefs.getBoolean("anuncio_voz", true));
        switchBateria.setChecked(prefs.getBoolean("bateria_activo", false));
        switchSilencioFoco.setChecked(prefs.getBoolean("silencio_foco", false));
        switchAutoActualizacion.setChecked(prefs.getBoolean("auto_actualizacion", false));

        // Mostrar versión instalada
        try {
            String vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            int    vc = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            tvVersionActual.setText("Versión " + vn + " (código " + vc + ")");
        } catch (Exception e) {
            tvVersionActual.setText("Versión 1.0");
        }

        seekVolNocturno.setProgress(volNocturno);
        actualizarTextoNocturno();
        actualizarTextoFade();
        actualizarTextoBateria();
        actualizarTextoEtiqueta();
        habilitarSeccionNocturna(switchNocturno.isChecked());
        habilitarSeccionFade(switchFade.isChecked());
        habilitarSeccionBateria(switchBateria.isChecked());
    }

    private void configurarListeners() {

        // Modo nocturno
        switchNocturno.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("nocturno_activo", checked).apply();
            habilitarSeccionNocturna(checked);
            anunciar(checked
                ? "Modo nocturno activado. Bajará el volumen entre las " + horaNocturnaInicio + " y las " + horaNocturnaFin + "."
                : "Modo nocturno desactivado.");
        });

        rowNocturnoHorario.setOnClickListener(v -> mostrarDialogoHorarioNocturno());

        seekVolNocturno.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                volNocturno = p;
                tvVolNocturno.setText(volNocturno + "%");
                seekVolNocturno.setContentDescription("Volumen nocturno: " + volNocturno + " por ciento");
                if (user) prefs.edit().putInt("nocturno_vol", volNocturno).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {
                anunciar("Volumen nocturno: " + volNocturno + " por ciento.");
            }
        });

        // Pausa con auriculares
        switchAuriculares.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("auriculares_pausa", checked).apply();
            anunciar(checked
                ? "Pausa con auriculares activada. Al conectar auriculares con cable, se pausará la redirección Bluetooth."
                : "Pausa con auriculares desactivada.");
        });

        // Pausa en llamadas
        switchLlamadas.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("llamadas_pausa", checked).apply();
            anunciar(checked
                ? "Pausa en llamadas activada. El audio se silenciará automáticamente al atender una llamada."
                : "Pausa en llamadas desactivada.");
        });

        // Fade de volumen
        switchFade.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("fade_activo", checked).apply();
            habilitarSeccionFade(checked);
            anunciar(checked
                ? "Fade activado. El audio bajará suavemente al detener."
                : "Fade desactivado. El audio cortará inmediatamente.");
        });

        rowFadeVel.setOnClickListener(v -> mostrarDialogoFade());

        // Anuncio de voz al cambiar estado
        switchAnuncioVoz.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("anuncio_voz", checked).apply();
            anunciar(checked
                ? "Anuncios de voz activados."
                : "Anuncios de voz desactivados.");
        });

        // Protección de batería
        switchBateria.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("bateria_activo", checked).apply();
            habilitarSeccionBateria(checked);
            anunciar(checked
                ? "Protección de batería activada. La redirección se detendrá cuando la batería baje del umbral configurado."
                : "Protección de batería desactivada.");
        });

        rowBateriaUmbral.setOnClickListener(v -> mostrarDialogoBateria());

        // Silencio al perder foco de audio
        switchSilencioFoco.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("silencio_foco", checked).apply();
            anunciar(checked
                ? "Silencio inteligente activado. Si otra app interrumpe el audio, la redirección se pausará automáticamente."
                : "Silencio inteligente desactivado.");
        });

        // Etiqueta personalizada de accesibilidad
        rowEtiqueta.setOnClickListener(v -> mostrarDialogoEtiqueta());

        // WhatsApp del desarrollador
        MaterialButton btnWsp = findViewById(R.id.btnWhatsapp);
        btnWsp.setOnClickListener(v -> abrirWhatsApp());

        // Buscar actualización manual
        btnBuscarActualizacion.setOnClickListener(v -> buscarActualizacionManual());

        // Auto actualización
        switchAutoActualizacion.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("auto_actualizacion", checked).apply();
            anunciar(checked
                ? "Actualizaciones automáticas activadas. La app buscará actualizaciones cada vez que la abrás."
                : "Actualizaciones automáticas desactivadas.");
        });
    }

    private void habilitarSeccionNocturna(boolean on) {
        float a = on ? 1f : 0.4f;
        rowNocturnoHorario.setAlpha(a);
        rowNocturnoHorario.setEnabled(on);
        rowNocturnoHorario.setClickable(on);
        rowVolNocturno.setAlpha(a);
        seekVolNocturno.setEnabled(on);
    }

    private void habilitarSeccionFade(boolean on) {
        float a = on ? 1f : 0.4f;
        rowFadeVel.setAlpha(a);
        rowFadeVel.setEnabled(on);
        rowFadeVel.setClickable(on);
    }

    private void habilitarSeccionBateria(boolean on) {
        float a = on ? 1f : 0.4f;
        rowBateriaUmbral.setAlpha(a);
        rowBateriaUmbral.setEnabled(on);
        rowBateriaUmbral.setClickable(on);
    }

    private void actualizarTextoNocturno() {
        String txt = "De " + horaNocturnaInicio + ":00 a " + horaNocturnaFin + ":00";
        tvNocturnoRango.setText(txt);
        rowNocturnoHorario.setContentDescription("Horario nocturno: " + txt + ". Tocá para cambiar.");
        tvVolNocturno.setText(volNocturno + "%");
    }

    private void actualizarTextoFade() {
        tvFadeDesc.setText("Duración: " + fadeSegundos + " segundos");
        rowFadeVel.setContentDescription("Velocidad del fade: " + fadeSegundos + " segundos. Tocá para cambiar.");
    }

    private void actualizarTextoBateria() {
        tvBateriaDesc.setText("Detener con menos del " + bateriaUmbral + "% de batería");
        rowBateriaUmbral.setContentDescription("Umbral de batería: " + bateriaUmbral + " por ciento. Tocá para cambiar.");
    }

    private void actualizarTextoEtiqueta() {
        String etiqueta = prefs.getString("etiqueta_app", "Sonido Independiente");
        tvEtiquetaValor.setText(etiqueta);
        rowEtiqueta.setContentDescription("Nombre de la app para el lector de pantalla: " + etiqueta + ". Tocá para cambiar.");
    }

    private void mostrarDialogoHorarioNocturno() {
        String[] opciones = {
            "Inicio: 20:00 — Fin: 8:00",
            "Inicio: 21:00 — Fin: 8:00",
            "Inicio: 22:00 — Fin: 8:00",
            "Inicio: 23:00 — Fin: 7:00",
            "Inicio: 00:00 — Fin: 6:00"
        };
        int[][] valores = {{20,8},{21,8},{22,8},{23,7},{0,6}};

        int selActual = 2;
        for (int i = 0; i < valores.length; i++) {
            if (valores[i][0] == horaNocturnaInicio && valores[i][1] == horaNocturnaFin) {
                selActual = i; break;
            }
        }

        new AlertDialog.Builder(this)
            .setTitle("Horario nocturno")
            .setSingleChoiceItems(opciones, selActual, (d, which) -> {
                horaNocturnaInicio = valores[which][0];
                horaNocturnaFin    = valores[which][1];
                prefs.edit()
                    .putInt("nocturno_inicio", horaNocturnaInicio)
                    .putInt("nocturno_fin", horaNocturnaFin)
                    .apply();
                actualizarTextoNocturno();
                anunciar("Horario nocturno: " + opciones[which]);
                d.dismiss();
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void mostrarDialogoFade() {
        String[] opciones = {"1 segundo","2 segundos","3 segundos","5 segundos","8 segundos"};
        int[]    valores  = {1, 2, 3, 5, 8};

        int selActual = 2;
        for (int i = 0; i < valores.length; i++) {
            if (valores[i] == fadeSegundos) { selActual = i; break; }
        }

        new AlertDialog.Builder(this)
            .setTitle("Velocidad del fade")
            .setSingleChoiceItems(opciones, selActual, (d, which) -> {
                fadeSegundos = valores[which];
                prefs.edit().putInt("fade_seg", fadeSegundos).apply();
                actualizarTextoFade();
                anunciar("Fade: " + opciones[which]);
                d.dismiss();
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void mostrarDialogoBateria() {
        String[] opciones = {"5%","10%","15%","20%","25%","30%"};
        int[]    valores  = {5, 10, 15, 20, 25, 30};

        int selActual = 2;
        for (int i = 0; i < valores.length; i++) {
            if (valores[i] == bateriaUmbral) { selActual = i; break; }
        }

        new AlertDialog.Builder(this)
            .setTitle("Umbral de batería")
            .setMessage("La redirección se detendrá automáticamente cuando la batería baje de este nivel.")
            .setSingleChoiceItems(opciones, selActual, (d, which) -> {
                bateriaUmbral = valores[which];
                prefs.edit().putInt("bateria_umbral", bateriaUmbral).apply();
                actualizarTextoBateria();
                anunciar("Umbral de batería: " + opciones[which]);
                d.dismiss();
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void mostrarDialogoEtiqueta() {
        android.widget.EditText et = new android.widget.EditText(this);
        et.setText(prefs.getString("etiqueta_app", "Sonido Independiente"));
        et.setHint("Nombre para el lector de pantalla");
        et.setContentDescription("Escribí cómo querés que el lector de pantalla identifique esta app");
        et.setPadding(48, 32, 48, 32);
        et.selectAll();

        new AlertDialog.Builder(this)
            .setTitle("Nombre para lector de pantalla")
            .setMessage("Este nombre reemplaza cómo TalkBack o NVDA identifica la app al navegar. Útil si tenés varias apps similares o querés un nombre más corto.")
            .setView(et)
            .setPositiveButton("Guardar", (d, w) -> {
                String nombre = et.getText().toString().trim();
                if (nombre.isEmpty()) nombre = "Sonido Independiente";
                prefs.edit().putString("etiqueta_app", nombre).apply();
                actualizarTextoEtiqueta();
                anunciar("Nombre de accesibilidad guardado: " + nombre + ".");
                Toast.makeText(this, "Guardado: " + nombre, Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void anunciar(String msg) {
        View root = findViewById(android.R.id.content);
        if (root != null) root.announceForAccessibility(msg);
    }

    private void buscarActualizacionManual() {
        btnBuscarActualizacion.setEnabled(false);
        btnBuscarActualizacion.setText("Buscando...");
        tvEstadoActualizacion.setText("Consultando el servidor de actualizaciones...");
        anunciar("Buscando actualizaciones. Por favor esperá.");

        actualizador.buscarActualizacion(false, new ActualizadorService.Callback() {
            @Override
            public void sinActualizacion(String versionActual) {
                btnBuscarActualizacion.setEnabled(true);
                btnBuscarActualizacion.setText("Buscar actualizaciones ahora");
                tvEstadoActualizacion.setText("Estás usando la versión más reciente (" + versionActual + "). No hay actualizaciones disponibles.");
                anunciar("La app está actualizada. Versión " + versionActual + " es la más reciente.");
            }

            @Override
            public void actualizacionDisponible(String versionNueva, int versionCodeNuevo, String urlApk) {
                btnBuscarActualizacion.setEnabled(true);
                btnBuscarActualizacion.setText("Buscar actualizaciones ahora");
                tvEstadoActualizacion.setText("Hay una actualización disponible: " + versionNueva + ". Tocá Instalar para descargarla.");
                anunciar("Hay una actualización disponible: versión " + versionNueva + ".");

                new androidx.appcompat.app.AlertDialog.Builder(ConfiguracionesActivity.this)
                    .setTitle("Actualización disponible")
                    .setMessage("Versión nueva: " + versionNueva + "\n\nLa app se descargará e instalará encima de la versión actual. Tus configuraciones y perfiles guardados se conservan.\n\n" + (actualizador.hayWifi() ? "Estás conectado a WiFi." : "Atención: no estás en WiFi, se usarán datos móviles."))
                    .setPositiveButton("Instalar ahora", (d, w) -> {
                        tvEstadoActualizacion.setText("Descargando " + versionNueva + "... Chequeá la barra de notificaciones.");
                        anunciar("Descargando la actualización. Te avisamos cuando esté lista para instalar.");
                        actualizador.descargarEInstalar(urlApk, versionNueva);
                    })
                    .setNegativeButton("Ahora no", null)
                    .show();
            }

            @Override
            public void error(String mensaje) {
                btnBuscarActualizacion.setEnabled(true);
                btnBuscarActualizacion.setText("Buscar actualizaciones ahora");
                tvEstadoActualizacion.setText("No se pudo verificar: " + mensaje);
                anunciar("Error al buscar actualizaciones: " + mensaje);
            }
        });
    }

    private void abrirWhatsApp() {
        try {
            String numero = "5435154351543512145223";
            Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/" + numero));
            intent.setPackage("com.whatsapp");
            startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/5435154351543512145223"));
                startActivity(intent);
            } catch (Exception ex) {
                Toast.makeText(this,
                    "No se pudo abrir WhatsApp. Número: 5435154351543512145223",
                    Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
