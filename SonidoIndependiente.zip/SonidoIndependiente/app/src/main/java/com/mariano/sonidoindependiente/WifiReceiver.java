package com.mariano.sonidoindependiente;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class WifiReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(intent.getAction())) return;

        NetworkInfo info = intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
        if (info == null || info.getState() != NetworkInfo.State.CONNECTED) return;

        String ssidConectado = obtenerSsid(context);
        if (ssidConectado == null || ssidConectado.isEmpty()) return;

        SharedPreferences prefs = context.getSharedPreferences("SonidoIndependiente", Context.MODE_PRIVATE);
        boolean activado = prefs.getBoolean("activado", false);
        if (!activado) return;

        String json = prefs.getString("perfiles_json", "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String wifiSsid = obj.optString("wifi_ssid", "");
                if (wifiSsid.isEmpty()) continue;

                if (wifiSsid.equalsIgnoreCase(ssidConectado)) {
                    aplicarPerfil(context, prefs, obj);
                    return;
                }
            }
        } catch (Exception ignored) {}
    }

    private String obtenerSsid(Context context) {
        try {
            WifiManager wm = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return null;
            WifiInfo wi = wm.getConnectionInfo();
            if (wi == null) return null;
            String ssid = wi.getSSID();
            if (ssid == null || ssid.equals("<unknown ssid>")) return null;
            return ssid.replace("\"", "");
        } catch (Exception e) {
            return null;
        }
    }

    private void aplicarPerfil(Context context, SharedPreferences prefs, JSONObject obj) {
        try {
            String dispositivo = obj.optString("dispositivo", "");
            String address     = "";
            int volumen        = obj.optInt("volumen", 80);
            int temporizador   = obj.optBoolean("temporizador", false) ? 30 : 0;

            List<String> apps = new ArrayList<>();
            JSONArray appsArr = obj.optJSONArray("apps");
            if (appsArr != null) {
                for (int j = 0; j < appsArr.length(); j++) {
                    apps.add(appsArr.getString(j));
                }
            }

            prefs.edit()
                .putString("dispositivo_nombre", dispositivo)
                .putInt("volumen", volumen)
                .apply();

            Intent serviceIntent = new Intent(context, AudioRedirectService.class);
            serviceIntent.putStringArrayListExtra("apps", new ArrayList<>(apps));
            serviceIntent.putExtra("dispositivo", dispositivo);
            serviceIntent.putExtra("address", address);
            serviceIntent.putExtra("volumen", volumen);
            serviceIntent.putExtra("temporizador", temporizador);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent);
            } else {
                context.startService(serviceIntent);
            }

        } catch (Exception ignored) {}
    }
}
