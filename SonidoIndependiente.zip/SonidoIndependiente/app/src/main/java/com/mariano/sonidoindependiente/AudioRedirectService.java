package com.mariano.sonidoindependiente;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Binder;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.List;

public class AudioRedirectService extends Service {

    private static final String CHANNEL_ID = "sonido_independiente";
    private static final int NOTIF_ID = 1;

    private final IBinder binder = new LocalBinder();
    private List<String> apps = new ArrayList<>();
    private String dispositivoNombre = "";
    private String dispositivoAddress = "";
    private int volumen = 80;
    private int temporizadorMinutos = 0;
    private CountDownTimer timer;
    private AudioManager audioManager;

    public class LocalBinder extends Binder {
        AudioRedirectService getService() { return AudioRedirectService.this; }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        crearCanalNotificacion();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            apps = intent.getStringArrayListExtra("apps");
            if (apps == null) apps = new ArrayList<>();
            dispositivoNombre = intent.getStringExtra("dispositivo");
            if (dispositivoNombre == null) dispositivoNombre = "";
            dispositivoAddress = intent.getStringExtra("address");
            if (dispositivoAddress == null) dispositivoAddress = "";
            volumen = intent.getIntExtra("volumen", 80);
            temporizadorMinutos = intent.getIntExtra("temporizador", 0);
        }

        startForeground(NOTIF_ID, construirNotificacion());
        aplicarVolumen();
        iniciarTemporizador();

        return START_STICKY;
    }

    private void crearCanalNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Sonido Independiente",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Redirección de audio activa");
            channel.setSound(null, null);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification construirNotificacion() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, AudioRedirectService.class);
        stopIntent.setAction("DETENER");
        PendingIntent stopPi = PendingIntent.getService(this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String appsStr = apps.isEmpty() ? "todo el audio del sistema" : String.join(", ", apps);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.servicio_activo))
            .setContentText(getString(R.string.servicio_desc, dispositivoNombre))
            .setSubText(appsStr)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .addAction(android.R.drawable.ic_media_pause, "Detener", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    private void aplicarVolumen() {
        if (audioManager == null) return;
        int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int targetVol = (int) (maxVol * (volumen / 100.0f));
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol,
            AudioManager.FLAG_SHOW_UI);
    }

    private void iniciarTemporizador() {
        if (timer != null) timer.cancel();
        if (temporizadorMinutos <= 0) return;

        long millis = temporizadorMinutos * 60 * 1000L;
        timer = new CountDownTimer(millis, 60000) {
            @Override
            public void onTick(long remaining) {
                int minutosRestantes = (int) (remaining / 60000);
                updateNotificationTimer(minutosRestantes);
            }
            @Override
            public void onFinish() {
                stopSelf();
            }
        }.start();
    }

    private void updateNotificationTimer(int minutosRestantes) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;

        String texto = getString(R.string.servicio_desc, dispositivoNombre)
            + " — " + minutosRestantes + " min restantes";

        Notification notif = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.servicio_activo))
            .setContentText(texto)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();

        nm.notify(NOTIF_ID, notif);
    }

    public void setVolume(int vol) {
        this.volumen = vol;
        aplicarVolumen();
    }

    public void setTimer(int minutos) {
        this.temporizadorMinutos = minutos;
        iniciarTemporizador();
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onDestroy() {
        if (timer != null) timer.cancel();
        super.onDestroy();
    }
}
