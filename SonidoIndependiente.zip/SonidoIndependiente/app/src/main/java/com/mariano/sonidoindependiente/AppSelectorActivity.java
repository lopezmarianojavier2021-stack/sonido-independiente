package com.mariano.sonidoindependiente;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppSelectorActivity extends AppCompatActivity {

    private final List<String> APPS_AUDIO = Arrays.asList(
        "com.google.android.youtube",
        "com.google.android.apps.youtube.music",
        "com.spotify.music",
        "com.sec.android.app.music",
        "com.google.android.music",
        "com.amazon.mp3",
        "com.pandora.android",
        "com.soundcloud.android",
        "com.deezer.android",
        "com.apple.android.music",
        "com.tidal.wave",
        "com.audible.application",
        "com.audacious_software.poweramp",
        "com.videolan.vlc",
        "fm.last.android",
        "com.clearchannel.iheartradio.controller",
        "com.tunein.radio",
        "com.aol.mobile.aolradio",
        "com.mapswithme.maps.pro",
        "com.waze",
        "com.google.android.apps.maps",
        "com.netflix.mediaclient",
        "com.amazon.avod.thirdpartyclient",
        "com.disney.disneyplus",
        "com.hbo.hbonow",
        "com.twitch.android.app",
        "com.discord"
    );

    private List<AppInfo> todasLasApps = new ArrayList<>();
    private List<String> appsSeleccionadas = new ArrayList<>();
    private AppAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_selector);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.seleccionar_apps);
        }

        appsSeleccionadas = getIntent().getStringArrayListExtra("apps_seleccionadas");
        if (appsSeleccionadas == null) appsSeleccionadas = new ArrayList<>();

        cargarApps();

        RecyclerView recycler = findViewById(R.id.recyclerApps);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AppAdapter(todasLasApps, appsSeleccionadas);
        recycler.setAdapter(adapter);

        MaterialButton btnConfirmar = findViewById(R.id.btnConfirmarApps);
        btnConfirmar.setOnClickListener(v -> confirmar());
    }

    private void cargarApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> instaladas = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        for (ApplicationInfo app : instaladas) {
            if (APPS_AUDIO.contains(app.packageName)
                    || (app.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                try {
                    String nombre = pm.getApplicationLabel(app).toString();
                    todasLasApps.add(new AppInfo(nombre, app.packageName));
                } catch (Exception ignored) {}
            }
        }

        Collections.sort(todasLasApps, (a, b) -> a.nombre.compareToIgnoreCase(b.nombre));
    }

    private void confirmar() {
        ArrayList<String> resultado = adapter.getSeleccionadas();
        Intent intent = new Intent();
        intent.putStringArrayListExtra("apps_seleccionadas", resultado);
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    static class AppInfo {
        String nombre;
        String packageName;
        AppInfo(String nombre, String packageName) {
            this.nombre = nombre;
            this.packageName = packageName;
        }
    }

    static class AppAdapter extends RecyclerView.Adapter<AppAdapter.VH> {
        private List<AppInfo> apps;
        private Set<String> seleccionadas;

        AppAdapter(List<AppInfo> apps, List<String> seleccionadas) {
            this.apps = apps;
            this.seleccionadas = new HashSet<>(seleccionadas);
        }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_app, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            AppInfo app = apps.get(position);
            holder.tvNombre.setText(app.nombre);
            holder.cbSeleccionada.setChecked(seleccionadas.contains(app.nombre));
            holder.cbSeleccionada.setContentDescription(
                app.nombre + (seleccionadas.contains(app.nombre) ? ", seleccionada" : ", no seleccionada")
            );

            View.OnClickListener click = v -> {
                if (seleccionadas.contains(app.nombre)) {
                    seleccionadas.remove(app.nombre);
                    holder.cbSeleccionada.setChecked(false);
                    holder.cbSeleccionada.setContentDescription(app.nombre + ", no seleccionada");
                } else {
                    seleccionadas.add(app.nombre);
                    holder.cbSeleccionada.setChecked(true);
                    holder.cbSeleccionada.setContentDescription(app.nombre + ", seleccionada");
                }
            };

            holder.itemView.setOnClickListener(click);
            holder.cbSeleccionada.setOnClickListener(click);
        }

        @Override
        public int getItemCount() { return apps.size(); }

        ArrayList<String> getSeleccionadas() {
            return new ArrayList<>(seleccionadas);
        }

        static class VH extends RecyclerView.ViewHolder {
            TextView tvNombre;
            CheckBox cbSeleccionada;
            VH(View v) {
                super(v);
                tvNombre = v.findViewById(R.id.tvAppNombre);
                cbSeleccionada = v.findViewById(R.id.cbApp);
            }
        }
    }
}
