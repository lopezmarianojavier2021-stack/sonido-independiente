package com.mariano.sonidoindependiente;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class DeviceSelectorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_selector);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.seleccionar_dispositivo);
        }

        cargarDispositivos();
    }

    private void cargarDispositivos() {
        BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
        List<DeviceInfo> dispositivos = new ArrayList<>();

        if (btAdapter != null && btAdapter.isEnabled()) {
            Set<BluetoothDevice> vinculados = btAdapter.getBondedDevices();
            for (BluetoothDevice device : vinculados) {
                dispositivos.add(new DeviceInfo(device.getName(), device.getAddress(), device.getType()));
            }
        }

        RecyclerView recycler = findViewById(R.id.recyclerDevices);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        if (dispositivos.isEmpty()) {
            findViewById(R.id.tvSinDispositivos).setVisibility(View.VISIBLE);
            recycler.setVisibility(View.GONE);
        } else {
            DeviceAdapter adapter = new DeviceAdapter(dispositivos, (nombre, address) -> {
                Intent result = new Intent();
                result.putExtra("nombre", nombre);
                result.putExtra("address", address);
                setResult(RESULT_OK, result);
                finish();
            });
            recycler.setAdapter(adapter);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    interface OnDeviceSelected {
        void onSelected(String nombre, String address);
    }

    static class DeviceInfo {
        String nombre;
        String address;
        int tipo;
        DeviceInfo(String nombre, String address, int tipo) {
            this.nombre = nombre != null ? nombre : "Dispositivo desconocido";
            this.address = address;
            this.tipo = tipo;
        }
        String tipoTexto() {
            switch (tipo) {
                case BluetoothDevice.DEVICE_TYPE_CLASSIC: return "Bluetooth clásico";
                case BluetoothDevice.DEVICE_TYPE_LE: return "Bluetooth LE";
                case BluetoothDevice.DEVICE_TYPE_DUAL: return "Bluetooth dual";
                default: return "Bluetooth";
            }
        }
    }

    static class DeviceAdapter extends RecyclerView.Adapter<DeviceAdapter.VH> {
        private List<DeviceInfo> devices;
        private OnDeviceSelected callback;

        DeviceAdapter(List<DeviceInfo> devices, OnDeviceSelected callback) {
            this.devices = devices;
            this.callback = callback;
        }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_device, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            DeviceInfo d = devices.get(position);
            holder.tvNombre.setText(d.nombre);
            holder.tvTipo.setText(d.tipoTexto() + " · " + d.address);
            holder.itemView.setContentDescription(
                d.nombre + ", " + d.tipoTexto() + ". Tocá para seleccionar."
            );
            holder.itemView.setOnClickListener(v -> callback.onSelected(d.nombre, d.address));
        }

        @Override
        public int getItemCount() { return devices.size(); }

        static class VH extends RecyclerView.ViewHolder {
            TextView tvNombre, tvTipo;
            VH(View v) {
                super(v);
                tvNombre = v.findViewById(R.id.tvDeviceNombre);
                tvTipo = v.findViewById(R.id.tvDeviceTipo);
            }
        }
    }
}
