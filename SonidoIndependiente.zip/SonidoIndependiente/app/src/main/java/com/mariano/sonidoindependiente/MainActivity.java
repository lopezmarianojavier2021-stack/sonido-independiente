package com.mariano.sonidoindependiente;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    static final int REQUEST_APPS = 101;
    static final int REQUEST_DEVICE = 102;
    static final int REQUEST_PERFIL = 103;
    static final int REQUEST_TIMER = 104;

    private SwitchMaterial switchMain, switchArranque;
    private MaterialButton btnAccion, btnConfiguraciones;
    private TextView tvEstadoTitulo, tvEstadoDesc;
    private TextView tvAppsValor, tvDispositivoValor, tvTemporizadorValor;
    private TextView tvVolumenValor;
    private SeekBar seekVolumen;
    private View layoutConfig, rowApps, rowDispositivo, rowTemporizador, rowPerfiles;

    private SharedPreferences prefs;
    private List<String> appsSeleccionadas = new ArrayList<>();
    private String dispositivoSeleccionado = null;
    private String dispositivoAddress = null;
    private int volumen = 80;
    private int temporizadorMinutos = 0;
    private boolean servicioActivo = false;

    private AudioRedirectService audioService;
    private boolean serviceBound = false;

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            AudioRedirectService.LocalBinder binder = (AudioRedirectService.LocalBinder) service;
            audioService = binder.getService();
            serviceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    private final ActivityResultLauncher<String[]> permisosLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            boolean granted = true;
            for (Boolean val : result.values()) {
                if (!val) { granted = false; break; }
            }
            if (granted) {
                habilitarUI(true);
            } else {
                mostrarDialogoPermisos();
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("SonidoIndependiente", Context.MODE_PRIVATE);

        inicializarVistas();
        cargarPreferencias();
        configurarListeners();
        solicitarPermisos();

        // Auto-actualización al abrir
        if (prefs.getBoolean("auto_actualizacion", false)) {
            new ActualizadorService(this).buscarActualizacion(true,
                new ActualizadorService.Callback() {
                    @Override public void sinActualizacion(String v) {}
                    @Override public void error(String msg) {}
                    @Override
                    public void actualizacionDisponible(String vNueva, int code, String url) {
                        new androidx.appcompat.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("Actualización disponible")
                            .setMessage("Hay una versión nueva: " + vNueva + ".\n\nTus datos se conservan al instalar encima. ¿Descargamos ahora?")
                            .setPositiveButton("Sí, instalar", (d, w) ->
                                new ActualizadorService(MainActivity.this)
                                    .descargarEInstalar(url, vNueva))
                            .setNegativeButton("Después", null)
                            .show();
                    }
                });
        }
    }

    private void inicializarVistas() {
        switchMain       = findViewById(R.id.switchMain);
        switchArranque   = findViewById(R.id.switchArranque);
        btnAccion        = findViewById(R.id.btnAccion);
        btnConfiguraciones = findViewById(R.id.btnConfiguraciones);
        tvEstadoTitulo   = findViewById(R.id.tvEstadoTitulo);
        tvEstadoDesc     = findViewById(R.id.tvEstadoDesc);
        tvAppsValor      = findViewById(R.id.tvAppsValor);
        tvDispositivoValor = findViewById(R.id.tvDispositivoValor);
        tvTemporizadorValor = findViewById(R.id.tvTemporizadorValor);
        tvVolumenValor   = findViewById(R.id.tvVolumenValor);
        seekVolumen      = findViewById(R.id.seekVolumen);
        layoutConfig     = findViewById(R.id.layoutConfig);
        rowApps          = findViewById(R.id.rowApps);
        rowDispositivo   = findViewById(R.id.rowDispositivo);
        rowTemporizador  = findViewById(R.id.rowTemporizador);
        rowPerfiles      = findViewById(R.id.rowPerfiles);
    }

    private void cargarPreferencias() {
        boolean activado = prefs.getBoolean("activado", false);
        switchMain.setChecked(activado);
        habilitarUI(activado);

        switchArranque.setChecked(prefs.getBoolean("arranque", false));

        Set<String> appsSet = prefs.getStringSet("apps", new HashSet<>());
        appsSeleccionadas = new ArrayList<>(appsSet);
        actualizarTextoApps();

        dispositivoSeleccionado = prefs.getString("dispositivo_nombre", null);
        dispositivoAddress = prefs.getString("dispositivo_address", null);
        actualizarTextoDispositivo();

        volumen = prefs.getInt("volumen", 80);
        seekVolumen.setProgress(volumen);
        tvVolumenValor.setText(volumen + "%");

        temporizadorMinutos = prefs.getInt("temporizador", 0);
        actualizarTextoTemporizador();

        actualizarBannerEstado();
        actualizarBotonAccion();
    }

    private void configurarListeners() {
        switchMain.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("activado", checked).apply();
            habilitarUI(checked);
            actualizarBannerEstado();
            actualizarBotonAccion();
            anunciarCambio(checked
                ? "Sonido independiente activado. Seleccioná las apps y el dispositivo de destino."
                : "Sonido independiente desactivado.");
        });

        rowApps.setOnClickListener(v -> {
            Intent i = new Intent(this, AppSelectorActivity.class);
            i.putStringArrayListExtra("apps_seleccionadas", new ArrayList<>(appsSeleccionadas));
            startActivityForResult(i, REQUEST_APPS);
        });

        rowDispositivo.setOnClickListener(v -> {
            Intent i = new Intent(this, DeviceSelectorActivity.class);
            startActivityForResult(i, REQUEST_DEVICE);
        });

        rowTemporizador.setOnClickListener(v -> mostrarDialogoTemporizador());

        rowPerfiles.setOnClickListener(v -> {
            Intent i = new Intent(this, PerfilActivity.class);
            i.putStringArrayListExtra("apps", new ArrayList<>(appsSeleccionadas));
            i.putExtra("dispositivo", dispositivoSeleccionado);
            i.putExtra("volumen", volumen);
            i.putExtra("temporizador_activo", temporizadorMinutos > 0);
            i.putExtra("arranque", switchArranque.isChecked());
            startActivityForResult(i, REQUEST_PERFIL);
        });

        seekVolumen.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                volumen = progress;
                tvVolumenValor.setText(volumen + "%");
                seekVolumen.setContentDescription("Volumen del dispositivo de destino: " + volumen + " por ciento");
                if (fromUser) prefs.edit().putInt("volumen", volumen).apply();
                if (serviceBound && audioService != null) audioService.setVolume(volumen);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {
                anunciarCambio("Volumen: " + volumen + " por ciento");
            }
        });

        switchArranque.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("arranque", checked).apply();
            anunciarCambio(checked ? "Arranque automático activado." : "Arranque automático desactivado.");
        });

        btnConfiguraciones.setOnClickListener(v ->
            startActivity(new Intent(this, ConfiguracionesActivity.class)));

        btnAccion.setOnClickListener(v -> {
            if (servicioActivo) {
                detenerServicio();
            } else {
                iniciarServicio();
            }
        });
    }

    private void habilitarUI(boolean habilitado) {
        float alpha = habilitado ? 1f : 0.4f;
        layoutConfig.setAlpha(alpha);
        layoutConfig.setEnabled(habilitado);

        rowApps.setClickable(habilitado);
        rowApps.setFocusable(habilitado);
        rowApps.setEnabled(habilitado);

        rowDispositivo.setClickable(habilitado);
        rowDispositivo.setFocusable(habilitado);
        rowDispositivo.setEnabled(habilitado);

        rowTemporizador.setClickable(habilitado);
        rowTemporizador.setFocusable(habilitado);
        rowTemporizador.setEnabled(habilitado);

        rowPerfiles.setClickable(habilitado);
        rowPerfiles.setFocusable(habilitado);
        rowPerfiles.setEnabled(habilitado);

        seekVolumen.setEnabled(habilitado);
        switchArranque.setEnabled(habilitado);
    }

    private void actualizarTextoApps() {
        if (appsSeleccionadas.isEmpty()) {
            tvAppsValor.setText(R.string.ninguna_app);
            rowApps.setContentDescription("Seleccionar aplicaciones. Actualmente: ninguna seleccionada.");
        } else {
            String txt = getString(R.string.apps_seleccionadas, appsSeleccionadas.size())
                + ": " + String.join(", ", appsSeleccionadas);
            tvAppsValor.setText(txt);
            rowApps.setContentDescription("Seleccionar aplicaciones. Actualmente: " + txt);
        }
    }

    private void actualizarTextoDispositivo() {
        if (dispositivoSeleccionado == null) {
            tvDispositivoValor.setText(R.string.ningun_dispositivo);
            rowDispositivo.setContentDescription("Seleccionar dispositivo Bluetooth. Actualmente: ninguno seleccionado.");
        } else {
            tvDispositivoValor.setText(dispositivoSeleccionado);
            rowDispositivo.setContentDescription("Seleccionar dispositivo Bluetooth. Actualmente: " + dispositivoSeleccionado);
        }
    }

    private void actualizarTextoTemporizador() {
        String txt;
        if (temporizadorMinutos == 0) {
            txt = getString(R.string.sin_limite);
        } else if (temporizadorMinutos < 60) {
            txt = getString(R.string.minutos, temporizadorMinutos);
        } else {
            int h = temporizadorMinutos / 60;
            txt = getString(R.string.horas, h);
        }
        tvTemporizadorValor.setText(txt);
        rowTemporizador.setContentDescription("Temporizador: " + txt + ". Tocá para cambiar.");
    }

    private void actualizarBannerEstado() {
        boolean on = switchMain.isChecked();
        if (!on) {
            tvEstadoTitulo.setText(R.string.estado_inactivo);
            tvEstadoDesc.setText(R.string.desc_activar);
        } else if (dispositivoSeleccionado == null) {
            tvEstadoTitulo.setText("Activado — falta el dispositivo");
            tvEstadoDesc.setText("Seleccioná un dispositivo Bluetooth de destino. Las apps son opcionales: si no elegís ninguna, se redirige todo el audio del sistema.");
        } else {
            String appsTexto = appsSeleccionadas.isEmpty()
                ? "todo el audio del sistema"
                : String.join(", ", appsSeleccionadas);
            tvEstadoTitulo.setText(getString(R.string.estado_activo, appsTexto, dispositivoSeleccionado));
            tvEstadoDesc.setText(servicioActivo
                ? "Redirección en curso."
                : "Listo para iniciar. Tocá el botón Iniciar.");
        }
    }

    private void actualizarBotonAccion() {
        boolean listo = switchMain.isChecked()
            && dispositivoSeleccionado != null;

        btnAccion.setEnabled(listo || servicioActivo);

        if (servicioActivo) {
            btnAccion.setText(R.string.detener);
            btnAccion.setContentDescription("Detener la redirección de audio");
        } else {
            btnAccion.setText(R.string.iniciar);
            btnAccion.setContentDescription(listo
                ? "Iniciar redirección de audio. Todo listo."
                : "Iniciar redirección. Seleccioná primero un dispositivo Bluetooth.");
        }
    }

    private void iniciarServicio() {
        Intent intent = new Intent(this, AudioRedirectService.class);
        intent.putStringArrayListExtra("apps", new ArrayList<>(appsSeleccionadas));
        intent.putExtra("dispositivo", dispositivoSeleccionado);
        intent.putExtra("address", dispositivoAddress);
        intent.putExtra("volumen", volumen);
        intent.putExtra("temporizador", temporizadorMinutos);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);

        servicioActivo = true;
        actualizarBannerEstado();
        actualizarBotonAccion();
        String appsAnuncio = appsSeleccionadas.isEmpty()
            ? "todo el audio del sistema"
            : String.join(", ", appsSeleccionadas);
        anunciarCambio("Redirección iniciada. " + appsAnuncio
            + " se enviará a " + dispositivoSeleccionado + ".");
    }

    private void detenerServicio() {
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
        stopService(new Intent(this, AudioRedirectService.class));
        servicioActivo = false;
        actualizarBannerEstado();
        actualizarBotonAccion();
        anunciarCambio("Redirección de audio detenida.");
    }

    private void mostrarDialogoTemporizador() {
        String[] opciones = {
            getString(R.string.sin_limite),
            getString(R.string.minutos, 15),
            getString(R.string.minutos, 30),
            getString(R.string.minutos, 60),
            getString(R.string.horas, 2),
            getString(R.string.horas, 4)
        };
        int[] valores = {0, 15, 30, 60, 120, 240};

        int seleccionActual = 0;
        for (int i = 0; i < valores.length; i++) {
            if (valores[i] == temporizadorMinutos) { seleccionActual = i; break; }
        }

        new AlertDialog.Builder(this)
            .setTitle(R.string.temporizador)
            .setSingleChoiceItems(opciones, seleccionActual, (dialog, which) -> {
                temporizadorMinutos = valores[which];
                prefs.edit().putInt("temporizador", temporizadorMinutos).apply();
                actualizarTextoTemporizador();
                if (serviceBound && audioService != null) {
                    audioService.setTimer(temporizadorMinutos);
                }
                anunciarCambio("Temporizador: " + opciones[which]);
                dialog.dismiss();
            })
            .setNegativeButton(R.string.cancelar, null)
            .show();
    }

    private void mostrarDialogoPermisos() {
        new AlertDialog.Builder(this)
            .setTitle(R.string.permiso_bt_titulo)
            .setMessage(R.string.permiso_bt_desc)
            .setPositiveButton(R.string.ir_a_ajustes, (d, w) -> {
                Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(android.net.Uri.parse("package:" + getPackageName()));
                startActivity(i);
            })
            .setNegativeButton(R.string.cancelar, null)
            .show();
    }

    private void solicitarPermisos() {
        List<String> permisos = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                permisos.add(Manifest.permission.BLUETOOTH_CONNECT);
                permisos.add(Manifest.permission.BLUETOOTH_SCAN);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                permisos.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        }

        if (!permisos.isEmpty()) {
            permisosLauncher.launch(permisos.toArray(new String[0]));
        }
    }

    private void anunciarCambio(String mensaje) {
        tvEstadoTitulo.announceForAccessibility(mensaje);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == REQUEST_APPS) {
            appsSeleccionadas = data.getStringArrayListExtra("apps_seleccionadas");
            if (appsSeleccionadas == null) appsSeleccionadas = new ArrayList<>();
            prefs.edit().putStringSet("apps", new HashSet<>(appsSeleccionadas)).apply();
            actualizarTextoApps();
            actualizarBannerEstado();
            actualizarBotonAccion();
        }

        if (requestCode == REQUEST_DEVICE) {
            dispositivoSeleccionado = data.getStringExtra("nombre");
            dispositivoAddress = data.getStringExtra("address");
            prefs.edit()
                .putString("dispositivo_nombre", dispositivoSeleccionado)
                .putString("dispositivo_address", dispositivoAddress)
                .apply();
            actualizarTextoDispositivo();
            actualizarBannerEstado();
            actualizarBotonAccion();
        }

        if (requestCode == REQUEST_PERFIL) {
            ArrayList<String> apps = data.getStringArrayListExtra("apps");
            String disp = data.getStringExtra("dispositivo");
            int vol = data.getIntExtra("volumen", 80);
            boolean tieneTemp = data.getBooleanExtra("temporizador_activo", false);
            boolean arr = data.getBooleanExtra("arranque", false);
            if (apps != null) appsSeleccionadas = apps;
            if (disp != null) dispositivoSeleccionado = disp;
            volumen = vol;
            seekVolumen.setProgress(volumen);
            tvVolumenValor.setText(volumen + "%");
            if (tieneTemp && temporizadorMinutos == 0) temporizadorMinutos = 30;
            else if (!tieneTemp) temporizadorMinutos = 0;
            actualizarTextoTemporizador();
            switchArranque.setChecked(arr);
            prefs.edit().putBoolean("arranque", arr).apply();
            actualizarTextoApps();
            actualizarTextoDispositivo();
            actualizarBannerEstado();
            actualizarBotonAccion();
            Toast.makeText(this, "Perfil aplicado", Toast.LENGTH_SHORT).show();
            anunciarCambio("Perfil aplicado correctamente.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
    }
}
