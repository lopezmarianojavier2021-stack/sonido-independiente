package com.mariano.sonidoindependiente;

import android.app.DownloadManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;

import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * ActualizadorService
 *
 * Consulta la API de GitHub Releases del repositorio para detectar
 * si hay una versión nueva del APK. Si la hay, la descarga con
 * DownloadManager y lanza el instalador del sistema.
 *
 * El repositorio se configura en GITHUB_REPO. El usuario debe
 * reemplazar "TU_USUARIO/TU_REPO" con su usuario y nombre de repo
 * de GitHub antes de compilar.
 *
 * La instalación encima de la versión anterior funciona siempre que
 * ambos APK estén firmados con la misma clave. GitHub Actions usa
 * la misma clave de debug en cada compilación, así que el reemplazo
 * funciona sin desinstalar.
 */
public class ActualizadorService {

    // ─── CONFIGURAR ESTO CON TU REPOSITORIO ───────────────────────
    private static final String GITHUB_REPO = "lopezmarianojavier2021-stack/sonido-independiente";
    // ──────────────────────────────────────────────────────────────

    private static final String CHANNEL_ID  = "actualizaciones";
    private static final int    NOTIF_ID    = 42;
    private static final String API_URL     =
        "https://api.github.com/repos/" + GITHUB_REPO + "/releases/latest";

    public interface Callback {
        void sinActualizacion(String versionActual);
        void actualizacionDisponible(String versionNueva, int versionCodeNuevo, String urlApk);
        void error(String mensaje);
    }

    private final Context context;
    private final SharedPreferences prefs;

    public ActualizadorService(Context context) {
        this.context = context.getApplicationContext();
        this.prefs   = this.context.getSharedPreferences("SonidoIndependiente", Context.MODE_PRIVATE);
    }

    /** Verifica si hay WiFi activa */
    public boolean hayWifi() {
        ConnectivityManager cm =
            (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null
            && info.isConnected()
            && info.getType() == ConnectivityManager.TYPE_WIFI;
    }

    /** Verifica si hay cualquier conexión de red */
    public boolean hayConexion() {
        ConnectivityManager cm =
            (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    /**
     * Consulta GitHub Releases en un hilo secundario.
     * Llama al callback en el hilo principal.
     */
    public void buscarActualizacion(boolean soloWifi, Callback callback) {
        new Thread(() -> {
            Handler main = new Handler(Looper.getMainLooper());

            if (soloWifi && !hayWifi()) {
                main.post(() -> callback.error("Se recomienda WiFi para buscar actualizaciones. Conectate a una red WiFi e intentá de nuevo."));
                return;
            }
            if (!hayConexion()) {
                main.post(() -> callback.error("Sin conexión a internet. Verificá tu red e intentá de nuevo."));
                return;
            }

            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(API_URL).openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/vnd.github.v3+json");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);

                int code = conn.getResponseCode();
                if (code != 200) {
                    main.post(() -> callback.error("No se pudo conectar al servidor de actualizaciones (código " + code + "). Intentá más tarde."));
                    return;
                }

                BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();

                JSONObject release = new JSONObject(sb.toString());
                String tagName    = release.getString("tag_name"); // ej: "v1.2"
                String body       = release.optString("body", "");

                // Extraer versionCode del cuerpo del release
                int remotoCode = 0;
                if (body.contains("VersionCode:")) {
                    String parte = body.substring(body.indexOf("VersionCode:") + 12).trim();
                    String[] tokens = parte.split("\\s+");
                    if (tokens.length > 0) {
                        try { remotoCode = Integer.parseInt(tokens[0].trim()); }
                        catch (NumberFormatException ignored) {}
                    }
                }

                // Obtener URL del APK en los assets del release
                String apkUrl = null;
                JSONArray assets = release.getJSONArray("assets");
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject asset = assets.getJSONObject(i);
                    String name = asset.getString("name");
                    if (name.endsWith(".apk")) {
                        apkUrl = asset.getString("browser_download_url");
                        break;
                    }
                }

                if (apkUrl == null) {
                    main.post(() -> callback.error("El release más reciente no tiene APK adjunto todavía. Intentá más tarde."));
                    return;
                }

                int localCode = obtenerVersionCodeLocal();
                final String versionNueva = tagName;
                final int    codeNuevo    = remotoCode > 0 ? remotoCode : (localCode + 1);
                final String urlFinal     = apkUrl;

                if (remotoCode > localCode || (remotoCode == 0 && !tagName.equals(obtenerVersionNameLocal()))) {
                    main.post(() -> callback.actualizacionDisponible(versionNueva, codeNuevo, urlFinal));
                } else {
                    main.post(() -> callback.sinActualizacion(obtenerVersionNameLocal()));
                }

            } catch (Exception e) {
                String msg = e.getMessage() != null ? e.getMessage() : "Error desconocido";
                main.post(() -> callback.error("Error al buscar actualizaciones: " + msg));
            }
        }).start();
    }

    /**
     * Descarga el APK con DownloadManager y lanza el instalador del sistema.
     * El instalador del sistema pide confirmación al usuario antes de instalar.
     */
    public void descargarEInstalar(String apkUrl, String versionNueva) {
        crearCanalNotificacion();

        // Notificación de inicio de descarga
        notificar("Descargando actualización " + versionNueva,
            "Conectate a WiFi si es posible. La descarga está en curso.");

        File destino = new File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
            "SonidoIndependiente-" + versionNueva + ".apk");

        if (destino.exists()) destino.delete();

        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(apkUrl))
            .setTitle("Sonido Independiente " + versionNueva)
            .setDescription("Descargando actualización...")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationUri(Uri.fromFile(destino))
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false);

        DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm == null) return;
        long downloadId = dm.enqueue(req);

        // Receptor para cuando termina la descarga
        BroadcastReceiver receptor = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                if (id != downloadId) return;
                ctx.unregisterReceiver(this);

                DownloadManager.Query q = new DownloadManager.Query().setFilterById(downloadId);
                Cursor cursor = dm.query(q);
                if (cursor != null && cursor.moveToFirst()) {
                    int status = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    cursor.close();
                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        lanzarInstalador(destino);
                    } else {
                        notificar("Error en la descarga",
                            "No se pudo descargar la actualización. Intentá de nuevo.");
                    }
                }
            }
        };

        context.registerReceiver(receptor,
            new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }

    private void lanzarInstalador(File apk) {
        Intent intent = new Intent(Intent.ACTION_VIEW);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Uri uri = FileProvider.getUriForFile(context,
                context.getPackageName() + ".fileprovider", apk);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else {
            intent.setDataAndType(Uri.fromFile(apk),
                "application/vnd.android.package-archive");
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

        notificar("Actualización lista",
            "Tocá para instalar. Tus datos se conservan al instalar encima de la versión anterior.");
    }

    private int obtenerVersionCodeLocal() {
        try {
            return context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            return 0;
        }
    }

    private String obtenerVersionNameLocal() {
        try {
            return context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "1.0";
        }
    }

    private void crearCanalNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Actualizaciones", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Notificaciones de actualización de la app");
            NotificationManager nm =
                (NotificationManager) context.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private void notificar(String titulo, String texto) {
        Intent i = new Intent(context, ConfiguracionesActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder n = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(texto))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManager nm =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, n.build());
    }
}
