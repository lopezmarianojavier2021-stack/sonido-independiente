# Sonido Independiente

App Android que permite redirigir el audio de apps específicas a un dispositivo Bluetooth distinto del que usa el resto del sistema. Funciona en cualquier Android 8 o superior, sin root, sin ser Samsung.

## Funciones

- Redirección de audio por app o de todo el sistema
- Selector de dispositivos Bluetooth vinculados
- Control de volumen independiente
- Temporizador de apagado automático
- Perfiles de configuración guardados
- **Modo Escena:** activación automática por red WiFi
- Modo nocturno con horario y volumen personalizados
- Pausa automática con auriculares con cable
- Silencio durante llamadas telefónicas
- Silencio inteligente al perder foco de audio
- Protección de batería configurable
- Fade de volumen al detener
- Arranque automático al encender el dispositivo
- Copia de seguridad de perfiles (exportar/importar, almacenamiento interno, SD o compartir)
- Actualizaciones automáticas desde GitHub
- Totalmente accesible con TalkBack y lectores de pantalla

## Requisitos

- Android 8.0 (Oreo) o superior
- Dispositivo Bluetooth vinculado previamente desde los ajustes del sistema

## Compilar

El proyecto se compila automáticamente con GitHub Actions en cada push a la rama `main`. El APK queda disponible en la pestaña **Actions** del repositorio y también como **Release**.

## Licencia

MIT — ver archivo [LICENSE](LICENSE)

## Desarrollado por

Mariano Javier López — Córdoba, Argentina
